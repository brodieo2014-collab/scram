// Run with: node test/smoke.cjs (requires Playwright and Chromium for this test only).
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || 'playwright');
const assert = require('node:assert/strict');
const http = require('node:http');
const path = require('node:path');
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const root = path.resolve(__dirname, '..');
const listen = server => new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

(async () => {
  let requests = 0;
  const fixture = http.createServer((req, res) => {
    requests++;
    res.setHeader('Content-Type', 'text/html');
    res.setHeader('X-Frame-Options', 'DENY'); // A raw iframe must not pass this test.
    res.setHeader('Content-Security-Policy', "frame-ancestors 'none'");
    if (req.url.startsWith('/second')) return res.end('<title>Second page</title><h1>Second page</h1><a href="/">First page</a>');
    if (req.url.startsWith('/result')) return res.end('<title>Form result</title><h1>Form result</h1><p>' + new URL(req.url, 'http://fixture').searchParams.get('q')?.replace(/[<>&]/g, '') + '</p>');
    res.end('<!doctype html><title>Orbit fixture</title><h1>Orbit fixture</h1><a href="/second">Second page</a><form action="/result"><label>Search <input name="q"></label><button>Submit</button></form><button id="count" onclick="this.textContent=\'JavaScript works\'">Run script</button>');
  });
  await listen(fixture);
  const fixturePort = fixture.address().port;
  const reservation = http.createServer(); await listen(reservation); const port = reservation.address().port;
  await new Promise(resolve => reservation.close(resolve));
  const url = `http://localhost:${port}`;
  const password = 'orbit-test-password-only';
  // Only this isolated child is permitted to connect to the fixture on loopback.
  // Production config keeps private IPs, direct IPs, and non-web ports blocked.
  const code = `await import('./server.mjs'); const { server:wisp }=await import('@mercuryworkshop/wisp-js/server'); Object.assign(wisp.options,{allow_loopback_ips:true,allow_private_ips:true,port_whitelist:[${fixturePort}],dns_method:async host=>{if(host!=='orbit-fixture.test')throw Error('Test blocks external network');return '127.0.0.1'}});`;
  const child = spawn(process.execPath, ['--input-type=module', '-e', code], { cwd: root, env: { ...process.env, PORT: String(port), HOST: '127.0.0.1', PUBLIC_ORIGIN: url, ACCESS_PASSWORD: password, RENDER: '' }, stdio: ['ignore', 'pipe', 'pipe'] });
  let logs = ''; child.stdout.on('data', data => logs += data); child.stderr.on('data', data => logs += data);
  let browser;
  try {
    let ready = false;
    for (let i = 0; i < 300; i++) { try { if ((await fetch(url + '/healthz')).ok) { ready = true; break; } } catch {} await delay(100); }
    assert.ok(ready, 'Server starts: ' + logs);
    assert.equal((await fetch(url, { redirect: 'manual' })).status, 302);
    assert.equal((await fetch(url + '/auth/login', { method: 'POST', headers: { Origin: 'https://wrong.invalid' } })).status, 403);
    const upgrade = await fetch(url + '/wisp/'); assert.equal(new URL(upgrade.url).pathname, '/login');
    browser = await chromium.launch({ headless: true, ...(process.env.CHROME_PATH ? { executablePath: process.env.CHROME_PATH } : {}) });
    const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
    page.setDefaultTimeout(10000);
    const errors = [], external = [];
    page.on('pageerror', error => errors.push(error.message));
    page.on('request', req => { if (!req.url().startsWith(url + '/') && /^https?:/.test(req.url())) external.push(req.url()); });
    await page.goto(url);
    await page.getByLabel('Workspace password').fill('wrong-password');
    await page.getByRole('button', { name: 'Open browser' }).click();
    await page.getByRole('alert').waitFor();
    await page.getByLabel('Workspace password').fill(password);
    await page.getByRole('button', { name: 'Open browser' }).click();
    await page.locator('#search').waitFor();
    await page.getByRole('tab').waitFor();
    fs.mkdirSync(path.join(root, 'test-output'), { recursive: true });
    await page.screenshot({ path: path.join(root, 'test-output', 'home-desktop.png') });
    await page.locator('#search').fill(`http://orbit-fixture.test:${fixturePort}/`);
    await page.locator('#search-form').evaluate(form => form.requestSubmit());
    let frame = page.frameLocator('.browser-frame:not([hidden])');
    await frame.getByRole('heading', { name: 'Orbit fixture' }).waitFor({ timeout: 25000 });
    await frame.getByRole('button', { name: 'Run script' }).click();
    await frame.getByRole('button', { name: 'JavaScript works' }).waitFor();
    await frame.getByRole('link', { name: 'Second page' }).click();
    await frame.getByRole('heading', { name: 'Second page' }).waitFor();
    await page.waitForFunction(() => document.getElementById('address').value.endsWith('/second'));
    await page.getByRole('button', { name: 'Back', exact: true }).click();
    await frame.getByRole('heading', { name: 'Orbit fixture' }).waitFor();
    await page.getByRole('button', { name: 'Forward', exact: true }).click();
    await frame.getByRole('heading', { name: 'Second page' }).waitFor();
    await page.getByRole('button', { name: 'Back', exact: true }).click();
    await frame.getByLabel('Search').fill('form-works');
    await frame.getByRole('button', { name: 'Submit' }).click();
    await frame.getByText('form-works').waitFor();
    await page.getByRole('button', { name: 'Reload page' }).click();
    await frame.getByRole('heading', { name: 'Form result' }).waitFor();
    await page.getByRole('button', { name: 'New tab', exact: true }).click();
    assert.equal(await page.getByRole('tab').count(), 2);
    await page.getByRole('tab').first().click();
    await frame.getByRole('heading', { name: 'Form result' }).waitFor();
    await page.locator('.tab-close').first().click();
    assert.equal(await page.locator('.browser-frame').count(), 0);
    await page.locator('#address').fill('javascript:alert(1)');
    await page.locator('#address-form').evaluate(form => form.requestSubmit());
    await page.getByRole('status').filter({ hasText: 'http://' }).waitFor();
    await page.setViewportSize({ width: 390, height: 844 });
    await page.getByRole('button', { name: 'Home', exact: true }).click();
    assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'No horizontal overflow on mobile');
    await page.screenshot({ path: path.join(root, 'test-output', 'home-mobile.png') });
    await page.getByRole('button', { name: 'About Orbit' }).click();
    page.once('dialog', dialog => dialog.accept());
    await page.getByRole('button', { name: 'Clear browsing data & sign out' }).click();
    await page.getByLabel('Workspace password').waitFor();
    assert.equal(await page.evaluate(() => navigator.serviceWorker.getRegistrations().then(items => items.length)), 0);
    assert.ok(requests >= 5, 'Requests traversed the real Wisp relay');
    assert.deepEqual(external, [], 'The browser did not fetch destinations directly');
    assert.deepEqual(errors, []);
    console.log('PASS: password gate, CSRF, real Wisp + Scramjet, frame-blocking headers, JS, links, form, back/forward, reload, tabs, URL validation, desktop/mobile, data clearing, logout.');
  } catch (error) { console.error(logs); throw error; }
  finally { await browser?.close(); child.kill(); await new Promise(resolve => fixture.close(resolve)); }
})().catch(error => { console.error(error); process.exitCode = 1; });
